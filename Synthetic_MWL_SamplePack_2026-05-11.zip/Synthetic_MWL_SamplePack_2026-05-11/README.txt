Synthetic MWL Sample Pack
=========================

Package:
  Synthetic_MWL_SamplePack_2026-05-11

Version:
  Sample / Evaluation

Test Date:
  2026-05-11

Modality:
  ES

Encoding:
  ASCII-normalized


1. What is this?
================

This package contains a small synthetic DICOM Modality Worklist (MWL) content sample.

It is intended for quick evaluation, development, import testing and basic workflow testing.

The data is synthetic.
It does not contain real patient data.


2. What is included?
====================

This package includes:

  csv/
    mwl_items_2026-05-11.csv

  json/
    mwl_items_2026-05-11.json

  metadata.json
  README.txt

The CSV file contains a flat list of MWL worklist items.

The JSON file contains the same MWL content in a structured machine-readable format.

The metadata.json file contains package information, counts, encoding information and generation details.


3. What is not included?
========================

This package does not include:

  - a DICOM Modality Worklist server
  - a DICOM C-FIND SCP
  - a PACS
  - a RIS
  - installation scripts
  - clinical production data
  - real patient data

The files in this package are intended to be imported into, mapped to or transformed for your own MWL test environment.


4. Intended use
===============

This sample pack can be used for:

  - evaluating the data structure
  - testing CSV import pipelines
  - testing JSON import or transformation logic
  - validating MWL mapping workflows
  - checking Patient / Accession / Scheduled Procedure Step consistency
  - quick developer testing
  - initial integration experiments

It is not intended for production use or clinical use.


5. Important MWL concept
========================

In Modality Worklist, one worklist item usually represents one Scheduled Procedure Step.

This means:

  1 Procedure = 1 MWL Item

A patient may appear multiple times if the patient has multiple scheduled procedures.

This is expected behavior and not necessarily a duplicate.

A real duplicate would be the same Accession Number or the same Scheduled Procedure Step ID appearing more than once.


6. Test date warning
====================

Many modalities and MWL clients query only the current test date or a narrow date range.

This sample package is generated for:

  2026-05-11

The CSV and JSON files contain Scheduled Procedure Step dates for this date.

If your test device filters by "today", the worklist may appear empty unless the system date/query date matches the dataset date.

For real tests, make sure that:

  - the device date is correct
  - NTP/system time is considered
  - the MWL query date matches the dataset date
  - or the dataset is regenerated/exported for the required test date


7. Encoding and special characters
==================================

This sample uses ASCII-normalized text for maximum compatibility.

Examples:

  Müller      -> MUELLER
  Köln        -> Koeln
  Gynäkologie -> Gynaekologie
  Straße      -> Strasse

This is intentional.

Some older DICOM/MWL systems or import pipelines do not handle Unicode or character set handling consistently.

A Unicode version with umlauts can be generated on request or produced by using the internal export pipeline with Unicode mode enabled.


8. CSV file
===========

File:

  csv/mwl_items_2026-05-11.csv

Typical columns include:

  PatientID
  PatientName
  PatientBirthDate
  PatientSex
  PatientCity
  PatientRegion
  AccessionNumber
  RequestedProcedureID
  RequestedProcedureDescription
  ScheduledProcedureStepID
  ScheduledProcedureStepDescription
  ScheduledProcedureStepStartDate
  ScheduledProcedureStepStartTime
  Modality
  Department
  CaseID
  EncounterRef
  StationAETitle
  ScheduledStationName

Typical date and time formats:

  PatientBirthDate:
    YYYYMMDD

  ScheduledProcedureStepStartDate:
    YYYYMMDD

  ScheduledProcedureStepStartTime:
    HHMMSS

Example:

  PatientName:
    MUELLER^MIA

  ScheduledProcedureStepStartDate:
    20260511

  ScheduledProcedureStepStartTime:
    103000


9. JSON file
============

File:

  json/mwl_items_2026-05-11.json

The JSON file contains the same MWL content in a structured form.

Typical structure:

  {
    "export_type": "mwl_json",
    "dataset_id": "...",
    "synthetic": true,
    "contains_real_patient_data": false,
    "count": 8,
    "items": [
      {
        "patient": {
          "patientId": "...",
          "patientName": "...",
          "birthDate": "...",
          "sex": "..."
        },
        "procedure": {
          "accessionNumber": "...",
          "scheduledProcedureStepId": "...",
          "scheduledProcedureStepStartDate": "...",
          "scheduledProcedureStepStartTime": "...",
          "modality": "ES"
        },
        "visit": {
          "caseId": "...",
          "encounterRef": "..."
        }
      }
    ]
  }


10. Metadata
============

File:

  metadata.json

The metadata file contains package-level information such as:

  - package name
  - package type
  - creation timestamp
  - test date
  - encoding mode
  - synthetic data flag
  - item counts
  - source counts
  - notes


11. Suggested evaluation steps
==============================

Recommended quick check:

  1. Open the CSV file.
  2. Verify that PatientName uses FAMILY^GIVEN format.
  3. Verify that ScheduledProcedureStepStartDate is 20260511.
  4. Verify that AccessionNumber is filled.
  5. Verify that ScheduledProcedureStepID is filled.
  6. Verify that Modality is ES.
  7. Try importing or mapping the CSV/JSON into your MWL test environment.
  8. Query your MWL system from your modality or test client.


12. Limitations of the sample
=============================

This is a small sample package.

It is intended to demonstrate the structure and usability of the data.

It does not represent a full production-size test dataset.

The sample may contain only a small number of:

  - patients
  - procedures
  - accession numbers
  - scheduled procedure steps

For realistic day-based or month-based testing, use a full content pack.


13. Full datasets
=================

Larger datasets can include:

  - more MWL items
  - full single-day packs
  - monthly packs
  - custom test dates
  - custom modality profiles
  - custom procedure catalogs
  - edge cases
  - larger patient populations
  - Unicode variants
  - additional export formats

Typical full package examples:

  Synthetic_MWL_ContentPack_YYYY-MM-DD
  Synthetic_MWL_MonthlyPack_YYYY-MM
  Custom Synthetic MWL Dataset


14. Support / customization
===========================

If you need a dataset for a specific test date, modality, procedure mix, item count or import format, a custom package can be generated.

Examples:

  - 50 MWL items for one test day
  - 1,500 MWL items over one month
  - endoscopy-specific test data
  - radiology-specific test data
  - ASCII or Unicode variants
  - special edge cases
  - system-specific mapping formats


15. Legal / data notice
=======================

This package contains synthetic test data only.

No real patient data is included.

The data is intended for software development, testing, QA and integration testing.

It must not be used for clinical diagnosis, treatment, billing or real patient care.